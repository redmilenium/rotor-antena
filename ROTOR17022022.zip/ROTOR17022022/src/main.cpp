//********************************************************************************************
// PROYECTO CONTROL ANTENA SATELITE
// CONEXION WIFI -  ***************************
/*    
  CON GEARBOX 100:1
  EN LA ROTOR9 VOY A INTRODUCIR UN OFFSET PARA MODIFICAR ERRORES DE POSICIONAMIENTO DURANTE LA INSTALACION
  CREO QUE ES TAN SIMPLE COMO EJECUTAR UNA RUTINA OFFSET DESPUES DEL POSICIOMANIENTO EN CERO

CONFIGURATION: https://docs.platformio.org/page/boards/espressif8266/d1_mini.html
PLATFORM: Espressif 8266 (2.6.2) > WeMos D1 R2 and mini
HARDWARE: ESP8266 240MHz, 80KB RAM, 4MB Flash
PACKAGES:
 - framework-arduinoespressif8266 3.20704.0 (2.7.4)    
 - tool-esptool 1.413.0 (4.13)
 - tool-esptoolpy 1.20800.0 (2.8.0)
 - toolchain-xtensa 2.40802.200502 (4.8.2)

ROTOR 17 VERSION CON 6400 PASOS POR GIRO COMPLETO =640.000  PASOS TOTALES
HAY QUE MODIFICAR EL CONTROLADOR DE MOTOR A 6400 PASOS
1.777,777777777778  pasos por grado
*/

// MAPA DE PUERTOS
// OUT               SCL/D1 - GPIO5  - 
// OUT               SDA/D2 - GPIO4  - 


// PUERTOS RECOMENDADOS PARA USO D1 - D2 - D5 - D6  Y D7
//  SOLAMENTE!!!!!!!!!!
//  SON LOS UNICOS RECOMENDADOS COMO ENTRADA DE SENSORES
//  EL RESTO: CUIDADIN  CUIDADIN

#include <Arduino.h>
#include <ESPAsyncTCP.h>
#include <LittleFS.h>
#include <FS.h>
#include <ESPAsyncWebServer.h>
#include <Arduino.h>
#include <ArduinoOTA.h>
#include <ESP8266WiFi.h>
#include <WifiUDP.h>
#include <NTPClient.h>
#include <Time.h>
#include <TimeLib.h>
#include <Timezone.h>
#include <EEPROM.h>
#include <sgp4.h>
Sgp4 sat;
#include <AccelStepper.h>
AccelStepper stepper(1,D6,D5);

 // Configura el cliente NTP UDP
WiFiUDP ntpUDP;
NTPClient timeClient(ntpUDP, "de.pool.ntp.org", 3600, 60000);//europe.pool.ntp.org -  es.pool.ntp.org - de.pool.ntp.org - 
// Horario Europa Central
TimeChangeRule CEST = {"CEST", Last, Sun, Mar, 2, 60};     // Hora de Verano de Europa Central
TimeChangeRule CET = {"CET ", Last, Sun, Oct, 3, 0};      // Hora Estandar de Europa Central
Timezone CE(CEST, CET);

WiFiClient  client;

// VARIABLES GLOBALES
//STRING + CHAR
String Sinicio;
String SHora;
String dia;
String mes;
String ano;
String tledia,tlemes,tleyear;
String hora ="";
String extractor="";
String response = "";
String str; 
String memosat="NORBI";
String message="Norbi";
String text="HR:";
String predi="";
String  info1;
String Norad="";
double conversor=1777.777777777778; // pasos por grado  6400 pasos por vuelta * 100 vueltas /360 grados = 1777.777777777778
// user y password ACCESO HTTP
const char* http_username = "admin";
const char* http_password = "abracadabra";
//INT + LONG
unsigned long refresco=millis();
unsigned long unixtime; //  = 1458950400;
unsigned long wsrefresh=millis();
double sec;
int timezone = 1 ;  //utc + 12
int  agno; 
int mon; 
int dei; 
int hr; 
int mn; 
int recolector=0;
int diasemana;
int valor;
int sal=1;
int rewifi;
int grados=0; // posicion en grados actual
int deriva=0;  // para evitar grabaciones innecesarias en eeprom, en automatico, solo grabo cada minuto
int burning;  // almacenara las grabaciones en eeprom
int testigo;


//BOOL
bool inicio=0;
bool horizontal=0;
bool error;
bool newsat=1;
bool automatico=1; // AUTOMATICO POR DEFECTO POR SI HAY REINICIO 
bool star=0;  // cuando arranco debo actualizar tle's
bool calibrator=0;
bool rotorerror=0;

//PROGRAMACION OFFSET 
long pasos=0;

// VARIABLES ESPECIALES

char satname[20] = "";
char tle_line1[100] = "";  //Line one from the TLE data
char tle_line2[100] = "";  //Line two from the TLE data

char satname_SL2B[20] = "SATLLA-2B";  //  
char tle_line1_SL2B[100] = "1     0U 12345AAA 22 20.66230492 +.00723306 +00000-0 -48351-5 0    04";  //Line one from the TLE data
char tle_line2_SL2B[100] = "2     0  97.4958  90.2027 0010089 234.8936 294.8022 15.13299264000006";  //Line two from the TLE data
char satname_MDQ1[20] = "MDQubeSAT-1";  //  
char tle_line1_MDQ1[100] = "1 70305U 12345AAA 22 17.44800789 +.00092914 +00000-0 +54953-2 0    08";  //Line one from the TLE data
char tle_line2_MDQ1[100] = "2 70305  97.4801  87.0351 0006605 254.7696  59.4997 15.10234611000003";  //Line two from the TLE data


 static const char reset1[] PROGMEM={"<!DOCTYPE html>"
"<html lang=\"es\">"
"<head>"
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0\">"
"<meta charset=\"UTF-8\">"
"<title>Control Centralizado IoT</title>"
"</head>"
"<body>"
"<style>"
"{box-sizing: border-box;}"
"body {font-family: Helvetica;text-align: center;background-position: center;background-repeat: no-repeat;background-size: cover;background-image:url('data');}"
"header { background-color: navy;  padding: 10px;  text-align: center;  font-size: 20px;  color: white;}" 
"footer {  background-color: navy;  padding: 10px;  text-align: center;  color: white;}"
".button { background-color: navy; border: none; color: white; padding: 5px 50px;width: 250px; margin: 0px;border-radius: 12px;border: 4px solid #ffffff;box-shadow: 0 9px #999;"
"text-decoration: none; font-size: 20px; margin: 2px; cursor: pointer;}"
".button:hover {background-color:blue}"
".button:active {background-color: SlateBlue;  box-shadow: 0 5px #666; transform: translateY(4px)}"
".caja {margin: 0 auto;text-align: center;font-family: Helvetica;font-size: 18px;padding: 3px 10px;box-sizing: padding-box;width: 300;margin: 0 0 25px; color: white; background-color:DodgerBlue;border: 4px solid white;border-radius: 8px;}"
".cajawhc {margin: 0 auto;text-align: center;font-family: Helvetica;font-size: 20px; padding: 3px 10px;width: 310px; background-color: SteelBlue;border: 4px solid DodgerBlue;border-radius: 12px;color: navy ;}"
".textarea{resize:vertical;width:100%;margin:0;height:800px;padding:5px;overflow:auto;}#t1{width:98%}"
".console{display:inline-block;text-align:center;margin:10px 0;width:98%;max-width:1080px;}"
"</style>"
"<header>  <h2>Control Centralizado IoT</h2></header>"
"<br/>"
"<br />"
"<div class=\"cajawhc\">"
"<p><caja class=\"caja\">RESETEANDO</caja></p>"
"<br />"
"</div>"
"<br />"
"<br/>"
"<footer>  <p>redmilenium@yahoo.es 2.022 OpenSource</p></footer>"
"</body>"
"</html>"};

static const char rotor[] PROGMEM={"<!DOCTYPE html>"
"<html lang=\"es\">"
"<head>"
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0\">"
"<meta charset=\"UTF-8\">"
"<title>Rotor IoT</title>"
"<script>"
"var gateway = 'ws://192.168.1.24/ws';"
"var websocket;"
"window.addEventListener('load', onLoad);"
"function initWebSocket() {"
"console.log('Trying to open a WebSocket connection...');"
"websocket = new WebSocket(gateway);"
"websocket.onopen    = onOpen;"
"websocket.onclose   = onClose;"
"websocket.onmessage = onMessage;" // <-- add this line
"}"
"function onOpen(event) {"
"console.log('Connection opened');"
"}"
"function onClose(event) {"
"console.log('Connection closed');"
"setTimeout(initWebSocket, 2000);"
"}"
"function onMessage(event) {"
"console.log('Server: ', event.data);"

"el = document.getElementById('ABRIR');"
"if(event.data.slice(0)=='OPEN') {el.className = 'buttonr';};"  
"if(event.data.slice(0)=='STOP'){el.className = 'button';};"   
"ella = document.getElementById('CERRAR');"
"if(event.data.slice(0)=='CLOSE') {ella.className = 'buttonr';};"  
"if(event.data.slice(0)=='STOP'){ella.className = 'button';};"     
"if(event.data.slice(0,2)=='i:') document.getElementById('irotor').value = event.data.slice(2);"   // valor seleccionado
"if(event.data.slice(0,2)=='i:') document.getElementById('grados').value = event.data.slice(2);"   // valor seleccionado
"if(event.data.slice(0,2)=='s:') document.getElementById('satelite').value = event.data.slice(2);"   // valor seleccionado
"if(event.data.slice(0,3)=='HR:') document.getElementById('t1').value = event.data.slice(3);"
"if(event.data.slice(0,3)=='off') {document.getElementById('AUTOMATICO').className= 'button';};"
"if(event.data.slice(0,2)=='on') {document.getElementById('AUTOMATICO').className= 'buttonon';};"
"if(event.data.slice(0,6)=='motoff') {document.getElementById('motor').className= 'button';};"
"if(event.data.slice(0,5)=='moton') {document.getElementById('motor').className= 'buttonon';};"
"if(event.data.slice(0,6)=='imanon') {document.getElementById('iman').className= 'buttonon';};"
"if(event.data.slice(0,7)=='imanoff') {document.getElementById('iman').className= 'button';};"
"}"
"function onLoad(event) {"
"initWebSocket();"
"}"
"function sendopen() {"
"websocket.send('OPEN');"
"}"
"function automatico() {"
"websocket.send('AUTO');"
"}"
"function sendclose() {"
"websocket.send('CLOSE');"
"}"
"function rotori() {"
"var x = document.getElementById('irotor').value;"
"websocket.send('i:'+x);"
"}"
"</script>"
"</head>"
"<body>"
"<style>"
"{box-sizing: border-box;}"
"body {font-family: Helvetica;text-align: center;background-position: center;background-repeat: no-repeat;background-size: cover;background-image:url('caja');}"
"header { background-color: navy;  padding: 10px;  text-align: center;  font-size: 20px;  color: white;}"
"footer {  background-color: navy;  padding: 10px;  text-align: center;  color: white;}"
".button { background-color: navy; color: white; padding: 7px 50px;width: 250px; margin: 0px;border-radius: 12px;border: 1px solid #ffffff;box-shadow: 7px 9px #1e2040;" //border: none;
"text-decoration: none; font-size: 20px; margin: 2px; cursor: pointer;}"
".button:hover {background-color:blue}"
".button:active {background-color: #1e2040; transform: translate(6px,8px)}"
".buttonon { background-color: navy; color: red; padding: 7px 50px;width: 250px; margin: 0px;border-radius: 12px;border: 1px solid #ffffff;box-shadow: 7px 9px #1e2040;" //border: none;
"text-decoration: none; font-size: 20px; margin: 2px; cursor: pointer;}"
".buttonon:hover {background-color:blue}"
".buttonon:active {background-color: #1e2040; transform: translate(6px,8px)}" 
".caja {margin: 0 auto;text-align: center;font-family: Helvetica;font-size: 18px;padding: 7px 10px;box-sizing: padding-box;width: 310;margin: 0 0 25px; color: white; background-color:DodgerBlue;border: 2px solid white;border-radius: 8px;}"
".cajawhc {margin: 0 auto;text-align: center;font-family: Helvetica;font-size: 20px; padding: 3px 10px;width: 310px; background-color: rgba(70, 130, 180, 0.4);border: 1px solid navy;border-radius: 12px;box-shadow: 7px 9px rgba(30, 32, 64, 0.9);}"
".cajawhl {margin: 0 auto;text-align: center;font-family: Helvetica;font-size: 19px; padding: 3px 10px;width: 310px; background-color: white;border: 4px solid DodgerBlue;border-radius: 12px;color: navy ;}"
".cajawh {margin: 0 auto;text-align: center;font-family: Helvetica;font-size: 25px; padding: 3px 10px;width: 100px; background:rgba(255,255,255,.8);border: 4px solid DodgerBlue;border-radius: 12px;color: navy ;}"
".textarea{resize:vertical;width:50%;margin:0;height:400px;padding:5px;overflow:auto;}#t1{width:98%}"
".console{display:inline-block;text-align:center;margin:10px 0;width:98%;max-width:1080px;}"
"</style>"
" <header>  <h2>Rotor IoT</h2></header>"
"<br/>"
"<br/>"
"<div class=\"cajawhc\">"
"<p><caja class='cajawh'>&nbsp;&nbsp;ROTOR IoT&nbsp;&nbsp;</caja></p>"
"<p><caja class=\"cajawhl\">&nbsp;<output name='satelite' id='satelite'></output>&nbsp;</caja></p>"
"<p><caja class=\"cajawhl\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<output name='grados' id='grados'></output>&nbsp;° &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</caja></p>"
"<p><caja class=\"cajawhl\"><input type='number' id='irotor' min='1' max='355'></caja></p>"
"<p><input type=\"button\" id='ABRIR' name='ABRIR' class=\"button\" value='MOVER' onclick='rotori()'></button></p>"
"<p><input type=\"button\" id='AUTOMATICO' name='AUTOMATICO' class=\"button\" value='AUTOMATICO' onclick='automatico()'></button></p>"
"<p><input type=\"button\" id='motor' name='motor' class=\"button\" value='((((MOTOR))))' ></button></p>"
"<p><input type=\"button\" id='iman' name='iman' class=\"button\" value='((((CERO))))' ></button></p>"
"</div>"
"<br />"
"<div class='console'><textarea rows='20' cols='30'readonly='' id='t1' wrap='off' name='t1'></textarea>"
"</div>"
"<br />"
"<div class=\"cajawhc\">"
"<p><input type=\"button\" class=\"button\" value=\"INFO\" onclick=\"window.location.href='http://192.168.1.24/info'\"/></p>"
"</div>"
"<br />"
"<br />"
"<br />"
"<br />"
"<br />"
"<footer>  <p>redmilenium@yahoo.es 2.022 OpenSource</p></footer>"
"</body>"
"</html>"}; 

//**********************************************************************************
//    RUTINA PREDICCION 
//**********************************************************************************
void Predict(int many)
{
     unixtime=timeClient.getEpochTime();
     unixtime=unixtime-3600;
    passinfo overpass;                       //structure to store overpass info
    sat.initpredpoint( unixtime , 0.0 );     //finds the startpoint
    
    bool error;
    predi="";
    for (int i = 0; i<many ; i++)
    {
        String mnplus;
        error = sat.nextpass(&overpass,20);     //search for the next overpass, if there are more than 20 maximums below the horizon it returns false
        delay(0);
        
        if ( error == 1){ //no error, prints overpass information
          
          invjday(overpass.jdstart ,timezone ,true , agno, mon, dei, hr, mn, sec);
       
          if(mn<=9)
          {
            mnplus="0"+String(mn);
          }else
          {
          mnplus=String(mn);
          }
          predi+="  Satélite dentro de cobertura: " + String(dei) + '/' + String(mon) + '/' + String(agno)+"\n";
          predi+="  Inicio: azimuth= " + String(overpass.azstart) + "° - hora: " + String(hr) + ':' + mnplus +"\n";
         
          invjday(overpass.jdmax ,timezone ,true , agno, mon, dei, hr, mn, sec);
          if(mn<=9)
          {
            mnplus="0"+String(mn);
          }else
          {
          mnplus=String(mn);
          }
          predi+="  Max: elevación= " + String(overpass.maxelevation) + "° - hora: " + String(hr) + ':' + mnplus +"\n";
        
          invjday(overpass.jdstop ,timezone ,true , agno, mon, dei, hr, mn, sec);
          if(mn<=9)
          {
            mnplus="0"+String(mn);
          }else
          {
             mnplus=String(mn);
          }
          predi+="  Stop: azimuth= " + String(overpass.azstop) + "° - hora: " + String(hr) + ':' + mnplus +"\n";
             
        }else{
            Serial.println("Prediction error");
            predi+="  Error de predicción\n";
        }
        delay(0);
        predi+="\n";
    }
    
}
//****************************************************************************************************
//**********************************************************************************
//    RUTINA CONEXION A LA WIFI
//**********************************************************************************
void scan()
{
  rewifi++;
  unsigned long currentTimeScan= millis(); 
  unsigned long previousTimeScan;
  const long timeoutTimeScan=10000;     
 
IPAddress ip(192,168,1,24);     //20095
IPAddress gateway(192,168,1,1);   
IPAddress subnet(255,255,255,0);   
IPAddress dns1(80,58,61,250);   
IPAddress dns2(80,58,61,254); 
  //Estas son las direcciones IP de los servidores DNS de Telefónica: 80.58.61.250. 80.58.61.254.
  
  // CONFIGURO VARIABLES PARA EL SSID Y EL PASSWORD 
  char ssid[] = "ssid 1";                   // añade tu ssid 
  char password[] = "password 1";     // añade tu password de la WIFI
  char ssid2[] = "ssid 2";
  char password2[] = "password 2";     // añade tu password de la WIFI

  
    WiFi.mode(WIFI_STA);
    WiFi.config(ip, gateway, subnet, dns1, dns2);
// scan....
     delay(5000);
     int n = WiFi.scanNetworks();
     long a=-100;
     long b=-100;
    for (int i = 0; i < n; ++i) 
    {
      if (WiFi.SSID(i)== ssid ) 
    {
       a=WiFi.RSSI(i);

    }
      if (WiFi.SSID(i)== ssid2) 
    {
       b=WiFi.RSSI(i);
    }
    
    }
     if (a>=b)
     {
      WiFi.begin(ssid,password);
     }else 
     {
      WiFi.begin(ssid2,password2);
     }

     currentTimeScan = millis();                
     previousTimeScan = currentTimeScan;            
   
     while ((WiFi.status() != WL_CONNECTED) && (currentTimeScan - previousTimeScan <= timeoutTimeScan)) 
     {
      currentTimeScan = millis();   
      delay(500);// aqui espero hasta tener WIFI
      ESP.wdtFeed();//REFRESCO EL WATCHDOG
     }
     delay(1000);
     if(WiFi.status() == WL_CONNECTED) Serial.println("ya tengo wifi");
}
//**********************************************************************************
//**********************************************************************************
void cero()
{
  unsigned long temporizador=millis();
if(grados<=20)  stepper.moveTo(40000);  //10000
while ((grados<=20)&&(millis()-temporizador<=5000))           // 5000 giro hacia la derecha para evitar deteccion de cero
    {   
       stepper.run();
       ESP.wdtFeed();
    }
temporizador=millis();
if(grados>=180)  stepper.moveTo(-200000);  //100000
//stepper.moveTo(-100000);
while ((grados>=180) && (millis()-temporizador<=20000))           // 10000 giro hacia la izquierda para evitar deteccion cero
    {   
       stepper.run();
       ESP.wdtFeed();
    }
temporizador=millis();
stepper.setCurrentPosition(0);
stepper.moveTo(-460000);//160000
while ((digitalRead(D2))&&(millis()-temporizador<=200000))  // 200000  y ya por fin busco el cero girando hacia la izquierda
    {                                                       // 
       stepper.run();
       ESP.wdtFeed();
    }
 stepper.stop();                                      // en cuanto detecto el cero, paro
stepper.setCurrentPosition(0);

if(millis()-temporizador>=200000) 
  {
   error=1; // si tardo mas de un minuto en encontrar el cero: malo, malo
              // activo error 
  }

   grados=0;
   sal=0;
   EEPROM.put(1,grados);
   EEPROM.commit();
   burning++;
   
// muevo el offset   ojo multiplicar los grados por 1777.77777777777778 en el caso de  6400 pasos por vuelta
pasos=0;         // 7=3112  8=3556  (9= 4000 - ok) grados de offset  KO 6 - 10 
stepper.moveTo(pasos); // pasos -xxxxx izquierda  +xxxxx  derecha
temporizador=millis();
while (millis()-temporizador<=10000)           // ajusto el offset 
    {   
       stepper.run();
       ESP.wdtFeed();
    }

stepper.setCurrentPosition(0);

}
//*****************************************************************************************************
// Create AsyncWebServer object on port 80
AsyncWebServer server(80);
AsyncWebSocket ws("/ws");


void InitOTA()
{
  // Port defaults to ESP32
  ArduinoOTA.setPort(8266);
  // Hostname defaults to esp8266-[ChipID]
  ArduinoOTA.setHostname("ESP8266_ROTOR");
  // No authentication by default
  ArduinoOTA.setPassword("abracadabra");


  ArduinoOTA.onStart([]() {
    String type;
    if (ArduinoOTA.getCommand() == U_FLASH) {
      type = "sketch";
    } else { // U_SPIFFS
      type = "filesystem";
    }

    // NOTE: if updating SPIFFS this would be the place to unmount SPIFFS using SPIFFS.end()
    //Serial.println("Start updating " + type);
  });

  ArduinoOTA.onEnd([]() {
    //Serial.println("\nEnd");
  });

  ArduinoOTA.onProgress([](unsigned int progress, unsigned int total) {
    //Serial.printf("Progress: %u%%\r", (progress / (total / 100)));
  });

  ArduinoOTA.onError([](ota_error_t error) {
    //Serial.printf("Error[%u]: ", error);
    if (error == OTA_AUTH_ERROR) {
      //Serial.println("Auth Failed");
    } else if (error == OTA_BEGIN_ERROR) {
      //Serial.println("Begin Failed");
    } else if (error == OTA_CONNECT_ERROR) {
      //Serial.println("Connect Failed");
    } else if (error == OTA_RECEIVE_ERROR) {
      //Serial.println("Receive Failed");
    } else if (error == OTA_END_ERROR) {
      //Serial.println("End Failed");
    }
  });

  ArduinoOTA.begin();
  //Serial.println("");
  //Serial.println("OTA iniciado");
}
//*****************************************************************************************************************
void handleWebSocketMessage(void *arg, uint8_t *data, size_t len)
{
  AwsFrameInfo *info = (AwsFrameInfo*)arg;
  if (info->final && info->index == 0 && info->len == len && info->opcode == WS_TEXT)
  {
    data[len] = 0;
    str = (char*)data;          //Conversión de los carácteres recibidos a cadena de texto
 

  if((str.substring(0,2))=="i:")
      {
       extractor=(str.substring(2));
       sal = extractor.toInt();         //Conversión de la cadena de texto a número
       grados=sal;
     if (sal>=360)  sal=360;
      stepper.moveTo(sal*conversor);
       horizontal=1;
       Serial.println(sal);
       ws.textAll("i:"+String(sal));
      }
    
  if((str.substring(0,4))=="AUTO")
      {
       automatico=!automatico;
       if(automatico) ws.textAll("on");
       if(!automatico) ws.textAll("off");
      }
  }
}
//*************************************************************************************************
void onEvent(AsyncWebSocket *server, AsyncWebSocketClient *client, AwsEventType type, void *arg, uint8_t *data, size_t len)
{
  switch (type) 
  {
    case WS_EVT_CONNECT:
     
       ws.textAll("i:"+String(grados));
       ws.textAll("s:"+message);
       if(automatico) ws.textAll("on");
       if(!automatico) ws.textAll("off");

      break;
    case WS_EVT_DISCONNECT:
      //Serial.printf("WebSocket client #%u disconnected\n", client->id());
      break;
    case WS_EVT_DATA:
      handleWebSocketMessage(arg, data, len);
      break;
    case WS_EVT_PONG:
    break;
    case WS_EVT_ERROR:
    break;
  }
}
//*************************************************************************************************
void initWebSocket() 
{
  ws.onEvent(onEvent);
  server.addHandler(&ws);
}
//*************************************************************************************************
void initsat()
{
  sat.init(satname,tle_line1,tle_line2);     //initialize satellite parameters 
  //Display TLE epoch time
  double jdC = sat.satrec.jdsatepoch;
  invjday(jdC , timezone, true, agno, mon, dei, hr, mn, sec);
  text+="Epoch: " + String(dei) + '/' + String(mon) + '/' + String(ano) + ' ' + String(hr) + ':' + String(mn) + ':' + String(sec)+"\n";
}
 
//**************************************************************************************************************
//**************************************   SETUP  **************************************************************
//**************************************************************************************************************
void setup()
{

EEPROM.begin(10);
EEPROM.get(1,grados);

info1.reserve(8500);
 // Serial port for debugging purposes
Serial.begin(115200);
Serial.println();
Serial.println(grados);

LittleFS.begin();
pinMode(D7, OUTPUT);       //ENABLE
digitalWrite(D7,LOW);
stepper.setMinPulseWidth(20);
stepper.setMaxSpeed(12800);//SPEED = Steps / second
stepper.setAcceleration(3200); //ACCELERATION = Steps /(second)^2
stepper.disableOutputs(); //disable outputs
stepper.setPinsInverted(false,false);  
pinMode(D2, INPUT_PULLUP);       //DETECTOR

scan();

sal=grados;

initWebSocket();


  //  pagina seleccion general
  server.on("/rotor", HTTP_GET, [](AsyncWebServerRequest * request)
  {
    
    if (!request->authenticate(http_username, http_password))
      return request->requestAuthentication();
     request->send(200, "text/html", rotor);
  });

  //  CABECERA get recepcion satelite en observacion
  //http://192.168.1.24/sat?sat=Norbi
  
   server.on("/sat", HTTP_GET, [](AsyncWebServerRequest * request) {
      AsyncWebParameter* p = request->getParam(0);
      message=p->value();
      newsat=1;
      ws.textAll("s:"+message);
      request->send(200, "text/plain", "OK "+ message);
  });

  server.on("/resort", HTTP_POST, [](AsyncWebServerRequest * request)
  {
    if (!request->authenticate(http_username, http_password))
    return request->requestAuthentication();
    request->send(200, "text/html", reset1);
    delay(100);
    ESP.restart();
  });
  //  pagina info general
  server.on("/info", HTTP_GET, [](AsyncWebServerRequest * request)
  {
    if (!request->authenticate(http_username, http_password))
      return request->requestAuthentication();

  info1 ="<!DOCTYPE html>"
"<html lang=\"es\">"
"<head>"
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0\">"
"<meta charset=\"UTF-8\">"
"<title>Control Rotor IoT</title>"
"</head>"
"<body>"
"<style>"
"body {font-family: Helvetica;text-align: center;background-position: center;background-repeat: no-repeat;background-size: cover;background-image:url('caja');}"
"header { background-color: navy;  padding: 10px;  text-align: center;  font-size: 20px;  color: white;}" 
"footer {  background-color: navy;  padding: 10px;  text-align: center;  color: white;}"
".button { background-color: navy; border: none; color: white; padding: 5px 50px;width: 250px; margin: 0px;border-radius: 12px;border: 4px solid #ffffff;box-shadow: 0 9px #999;"
"text-decoration: none; font-size: 20px; margin: 2px; cursor: pointer;}"
".button:hover {background-color:blue}"
".button:active {background-color: SlateBlue;  box-shadow: 0 5px #666; transform: translateY(4px)}"
".caja {margin: 0 auto;text-align: center;font-family: Helvetica;font-size: 18px;padding: 3px 10px;width: 300px;margin: 0 0 25px; color: white; background-color:DodgerBlue;border: 4px solid white;border-radius: 8px;}"
".cajawhc {margin: 0 auto;text-align: center;font-family: Helvetica;font-size: 20px; padding: 3px 10px;width: 310px; background-color: SteelBlue;border: 4px solid DodgerBlue;border-radius: 12px;color: navy ;}"
"</style>"
"<header>  <h2>Rotor IoT</h2></header>"
"<br/>"
"<br />"
"<div class=\"cajawhc\">"
"<p><caja class=\"caja\">Start</caja></p>"
"<p><caja class=\"caja\">&nbsp;&nbsp;&nbsp;FECHA = "+dia+"/"+mes+"/"+ano+" &nbsp;&nbsp;</caja></p>"
"<p><caja class=\"caja\">Hora " + Sinicio + " - online "+((String)(millis()/3600000)) +" horas </caja></p>"
"<p><caja class=\"caja\">SSID: "+(WiFi.SSID())+"</caja></p>"
"<p><caja class=\"caja\">Nivel "+((String)(WiFi.RSSI()))+" dbm</caja></p>"
"<p><caja class=\"caja\">REC.WIFI "+((String)(rewifi))+"</caja></p>"
"<p><caja class=\"caja\">Speed "+((String)(ESP.getCpuFreqMHz()))+" Mhz</caja></p>"
"<p><caja class=\"caja\">BURNING "+((String)(burning))+"</caja></p>"
"<p><caja class=\"caja\">ROTOR17022022</caja></p>"
"</div>"
"<br />"
"<div class=\"cajawhc\">"
"<p><input type=\"button\" class=\"button\" value='ATRAS' onclick=\"window.location.href='http://192.168.1.24/rotor'\"></p>"
"</div>"
"<br/>"
"<br/>"
"<br/>"
"<div class=\"cajawhc\">"
"<form action=\"/resort\"method=\"post\">"
"<p><button class='button' name='RESET' value='RESET'>RESET</button></p>"
"</form>"
"</div>"
"<br/>"
"<footer>  <p>redmilenium@yahoo.es 2.022 OpenSource</p></footer>"
"</body>"
"</html>";

    request->send(200, "text/html", info1);
  });
  // envio de la imagen data desde spiffs
  server.on("/data", HTTP_GET, [](AsyncWebServerRequest * request)
  {
     request->send(LittleFS, "/data.jpg", "image/jpeg");
  });
   // envio de la imagen caja desde spiffs
  server.on("/caja", HTTP_GET, [](AsyncWebServerRequest * request)
  {
     request->send(LittleFS, "/rotor.jpg", "image/jpeg");
  });
  // menu Pagina no encontrada
  server.onNotFound([](AsyncWebServerRequest * request)
  {
    request->send(404);
  });

// Start server
server.begin();
    
// start OTA
InitOTA();

//******************************************************************************************
timeClient.begin(); // inicializo el timeclient despues de estar conectado a internet
//******************************************************************************************
if (WiFi.status() == WL_CONNECTED) //comprobar estado de conexion del WIFI
  {   
    // Obtengo la hora
    timeClient.update();
    //*************************************************************************
    unsigned long utc =  timeClient.getEpochTime();
    // Convertir marca de tiempo UTC UNIX a hora local
    time_t t = CE.toLocal(utc);  // y tomo nota de la hora actual
    hora ="";
    SHora="";
    hora += hour(t);
    SHora += hour(t);
    SHora += ":";
    if(minute(t) < 10) hora += "0";
    if(minute(t) < 10) SHora += "0";
    hora += minute(t);
    SHora += minute(t);
    if(second(t) < 10) hora += "0";
    hora += second(t);
    valor = hora.toInt();//convierte un String a int
    diasemana=weekday(t);
    tledia= day(t);
    tlemes= month(t);
    tleyear= year(t);
    
    Sinicio=SHora;
    inicio=1;
    dia= day(t);
    mes= month(t);
    ano= year(t);
 
  }

//******************************************************************************************
unixtime=timeClient.getEpochTime();
unixtime=unixtime-3600;
sat.site(42.456002,-2.435735,400); //set site latitude[°], longitude[°] and altitude[m]
initsat();
sat.findsat(unixtime);

cero(); //Cuando arranco lo primero que hago es poner la antena a 0 grados.
stepper.enableOutputs(); //enable pins
Serial.println("cero");
Serial.println("fin setup");
}
//**************************************************************************************************************
//**************************************    LOOP  **************************************************************
//**************************************************************************************************************
void loop()
{
  //********************************************************************************************
// *************************   COMPRUEBO SI ESTOY CONECTADO A LA WIFI*************************
//********************************************************************************************
  if (WiFi.status() != WL_CONNECTED) //comprobar estado de conexion del WIFI
  {   
     delay(1000);
     rewifi++;
     scan();
  }
  ws.cleanupClients();
  ArduinoOTA.handle();
  stepper.run();
 
  if(horizontal)
  {
    horizontal=0;
    EEPROM.get(1,testigo);
    if(abs(testigo-grados)>45)
    {
       EEPROM.put(1,grados);
       EEPROM.commit();
       burning++;
    }
  }

  if ((newsat)&&(memosat!=message)&&automatico)
 {
 
    if (message=="TEST") Norad="46494";
    if (message=="Norbi") Norad="46494";
    if (message=="FEES") Norad="48082";
    if (message=="FEES2") Norad="51441";//
    if (message=="MDQubeSAT-1") Norad="50988";   // ojo
    if (message=="FossaSat-2E1") Norad="50985";
    if (message=="FossaSat-2E2") Norad="51025"; // ojo 51025
    if (message=="FossaSat-2E3") Norad="51024"; // ojo
    if (message=="FossaSat-2E4") Norad="50987";
    if (message=="FossaSat-2E5") Norad="51001";
    if (message=="FossaSat-2E6") Norad="50991";
    if (message=="SATLLA-2A") Norad="51014";   //51024  51014
    if (message=="SATLLA-2B") Norad="51014";    // 
    //if (message=="SSIET") Norad="47716";
    //if (message=="SDSat") Norad="47721";

    
   client.setTimeout(3000);
  if (client.connect("celestrak.com", 80)) 
  {
    Serial.println("Conectado al servidor!");
    client.println("GET /NORAD/elements/gp.php?CATNR="+Norad+"&FORMAT=TLE HTTP/1.0"); 
    client.println("Host: celestrak.com");
    client.println("Connection: close");
  }
  
 if (client.println() == 0) 
   {
    Serial.println(F("Failed to send request"));
    client.stop();
    newsat=1;
    return;
   }

  // Check HTTP status
  char status[32] = {0};
  client.readBytesUntil('\r', status, sizeof(status));
  // It should be "HTTP/1.0 200 OK" or "HTTP/1.1 200 OK"
  if (strcmp(status + 9, "200 OK") != 0) 
  {
    Serial.print(F("Unexpected response: "));
    Serial.println(status);
    client.stop();
    newsat=1;
    return;
  }

  // Skip HTTP headers
  char endOfHeaders[] = "\r\n\r\n";
  if (!client.find(endOfHeaders)) 
  {
    Serial.println(F("Invalid response"));
    client.stop();
    newsat=1;
    return;
  }

    while (client.available()) 
    {
      char c=client.read();
      response += c;
    }

  

   client.stop();

  if (response.length()>=142)
  {
     newsat=0;
     memosat=message;
     int x=response.length()-142;
     String text1=(response.substring(x, x+69));
     String text2=(response.substring(x+71));
     Serial.println(text1);
     Serial.println(text2);

    // response=message+ " tle OK!!!\n"; 
     strncpy (tle_line1,text1.c_str(),text1.length());
     strncpy (tle_line2,text2.c_str(),text2.length());
     response=message+"  "+ tledia+"/"+tlemes+"/"+tleyear+" "+SHora+" TLE ACTUALIZADO   OK!!!\n";
  }

    if (message=="MDQubeSAT-1")
    {
    strncpy (satname,satname_MDQ1, strlen((char*)satname_MDQ1));
    strncpy (tle_line1,tle_line1_MDQ1, strlen((char*)tle_line1_MDQ1));
    strncpy (tle_line2,tle_line2_MDQ1, strlen((char*)tle_line2_MDQ1));
    }



    initsat();
    sat.findsat(unixtime);
    Predict(6);

 
  //response="";
}



//**************************************************************************************************************
//  OBTENGO NUEVOS DATOS REFERENTES AL SATELITE EN OBSERVACION 
// SI ESTOY EN AUTOMATICO Y EL SATELITE A MENOS DE 3500 KM COMIENZO EL SEGUIMIENTO DEL MISMO
//**************************************************************************************************************
  if(millis()-refresco>=500)//5000
  {
    refresco=millis();
    unixtime=timeClient.getEpochTime();
    unixtime=unixtime-3600; 
    sat.findsat(unixtime);

// SI ESTOY EN AUTOMATICO Y EL SATELITE A MENOS DE 3500 KM COMIENZO EL SEGUIMIENTO DEL MISMO
    if((sat.satDist <=3500)&&automatico) // si el satelite esta a menos de 3500 Km y estoy en automatico
       {   
       // ajusto sal a la posicion de azimuth
         sal=sat.satAz;   
         grados=sal;     
         stepper.moveTo(sat.satAz*conversor);
         horizontal=1;
       
       }
  }

//**************************************************************************************************************
//  ENVIO LOS DATOS VIA WS  
//**************************************************************************************************************
  if(millis()-wsrefresh>=1000)//5000
  {
    wsrefresh=millis();
    invjday(sat.satJd , timezone,true, agno, mon, dei, hr, mn, sec);
    if(automatico)  text="HR:\n  Rotor Automático\n";
    if(!automatico)  text="HR: \n  Rotor Manual\n";
    if (rotorerror) text+="  Error en rotor\n";
    if(!rotorerror)  text+="  Rotor operativo\n";
    text+="  " +String(dei) + '/' + String(mon) + '/' + String(agno) + ' ' + String(hr) + ':' + String(mn) + ':' + String(sec)+"\n";
    text+="  OFFSET " + String (pasos/1777)+"°\n";
    text+="  Satélite "+message+"\n";   
    text+="  GRADOS SATELITE: " + String (sat.satAz)+" °\n";
    text+="  PASOS  SATELITE: " + String (sat.satAz*conversor)+"\n";
    text+="  GRADOS   ROTOR: " + String (stepper.currentPosition()/conversor)+" °\n";
    text+="  PASOS    ROTOR: " + String (stepper.currentPosition())+"\n";

    if((sat.satDist <=3000)&&automatico)   ws.textAll("i:"+String(sal));

    text+="\n";
    text+="  azimuth = " + String( sat.satAz) + "° - elevation = " + String(sat.satEl) + "° - distancia = " + String(sat.satDist)+" Km.\n";
    text+="  latitud = " + String( sat.satLat) + "° - longitud = " + String( sat.satLon) + "° - altitud = " + String( sat.satAlt)+" Km.\n";


  switch(sat.satVis)
          {
              case -2:
                  text+="  No visible : Satélite bajo el horizonte\n";
                  break;
              case -1:
                  text+="  Visible : Daylight\n";
                  break;
              default:
                  text+="  Visible : " + String(sat.satVis)+"\n";
                  break;
          }

     text+="\n  " +response+"\n";
     text+="  " +String (tle_line1) +"\n";
     text+="  " +String (tle_line2) +"\n";
     text+=predi+"\n";
     ws.textAll(text);
      if(stepper.isRunning())
      {
        ws.textAll("moton");
      }else
      {
        ws.textAll("motoff");
      }
      if(digitalRead(D2))
      {
        ws.textAll("imanoff");
      }else
      {
        ws.textAll("imanon");
      }
     
       
  }

}
//**************************************************************************************************************
//**************************************************************************************************************
//**************************************  FINAL LOOP  **********************************************************
//**************************************************************************************************************
//**************************************************************************************************************