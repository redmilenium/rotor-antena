# Sgp4-Library
Library for calculating satellite positions and predicting overpasses.
Currently only support for ESP8266.

# Credits
Original source code written by David Vallado: https://celestrak.com/software/vallado-sw.asp  
[Coordinate transformation](https://github.com/gradyh/ISS-Tracking-Pointer) ported by Grady Hillhouse. It is distributed under MIT license.
